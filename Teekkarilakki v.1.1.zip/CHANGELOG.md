# Teekkarilakki pack 1.21.4 Changelog
Author Frans Härkönen

## Version 1.1 - More Lakkis
Added all other Teekkarilakkis to the pack.

BUGS: Fuksilakki is still missing

## Version 1.0 - Initial release
Added 1 Teekkarilakki to the pack.