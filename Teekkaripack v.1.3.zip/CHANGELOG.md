# Teekkarilakki pack 1.21.4 Changelog
Author Frans Härkönen

## Version 1.3 - Added Seresauva
Added seresauva for maintaining patience at Sitsit.

BUGS: The sauva disappears when you are too drunk...

## Version 1.2 - Added MC-Kalu
Added MC-kalu to the pack.
The book has 104 pages of Teekkari songs.

USAGE: Spawn it using command blocks and the command is in the laulukalu.txt.

Improvements: My singing skills...

## Version 1.1 - More Lakkis
Added all other Teekkarilakkis to the pack.

BUGS: Fuksilakki is still missing

## Version 1.0 - Initial release
Added 1 Teekkarilakki to the pack.